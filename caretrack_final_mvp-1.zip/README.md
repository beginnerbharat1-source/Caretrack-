# CareTrack — final MVP

## Run
1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open http://localhost:3000

## Included
- Patient dashboard
- Hypertension/BP tracking
- Diabetes/glucose tracking
- Asthma/peak-flow and symptom tracking
- Trend charts
- Medicine reminders
- Patient profile
- Doctor-report export
- Language selector: English, Marathi, Hindi, Spanish, French, Arabic
- Local JSON backend for MVP development
- Responsive mobile-first UI
- Emergency safety messaging

## Important before real clinical deployment
This package is an MVP, NOT a production medical service. Before storing real patient information:
- replace JSON storage with a properly secured database
- add authenticated accounts and role-based access
- encrypt data in transit and at rest
- add audit logs, backups, rate limiting, CSRF/session protections as appropriate
- have clinicians validate every threshold, alert and action plan
- implement consent, privacy, deletion/export workflows
- perform accessibility and translation review
- obtain country-specific legal/privacy/medical-device review (for example India and other target markets)
- never automatically change a patient's medication based only on an app alert
