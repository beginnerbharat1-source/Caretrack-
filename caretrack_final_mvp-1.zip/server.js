const express=require("express"), fs=require("fs"), path=require("path");
const app=express(), PORT=process.env.PORT||3000;
const DATA=path.join(__dirname,"data.json");
app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"public")));
function read(){try{return JSON.parse(fs.readFileSync(DATA,"utf8"))}catch{return {patients:[],readings:[],meds:[]}}}
function write(d){fs.writeFileSync(DATA,JSON.stringify(d,null,2))}
app.get("/api/health",(req,res)=>res.json({ok:true,app:"CareTrack",version:"1.0.0"}));
app.get("/api/data",(req,res)=>res.json(read()));
app.post("/api/reading",(req,res)=>{
 const d=read(), r=req.body;
 if(!r || (!r.sys&&!r.glucose&&!r.peak)) return res.status(400).json({error:"At least one reading is required"});
 r.id=Date.now().toString(); r.createdAt=new Date().toISOString(); d.readings.unshift(r); write(d); res.json(r);
});
app.post("/api/profile",(req,res)=>{const d=read();d.profile=req.body||{};write(d);res.json(d.profile)});
app.post("/api/med",(req,res)=>{const d=read(),m=req.body||{};m.id=Date.now().toString();d.meds.push(m);write(d);res.json(m)});
app.delete("/api/med/:id",(req,res)=>{const d=read();d.meds=d.meds.filter(x=>x.id!==req.params.id);write(d);res.json({ok:true})});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`CareTrack running on http://localhost:${PORT}`));
